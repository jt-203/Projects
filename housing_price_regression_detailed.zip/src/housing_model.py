
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

def load_data(path):
    return pd.read_csv(path)

def eda(df):
    print(df.describe())
    sns.pairplot(df[['median_income', 'house_age', 'avg_rooms', 'avg_bedrooms', 'median_house_value']])
    plt.tight_layout()
    plt.savefig('../reports/pairplot.png')
    plt.close()

def train_model(df):
    X = df[['median_income', 'house_age', 'avg_rooms', 'avg_bedrooms']]
    y = df['median_house_value']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = LinearRegression()
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("R^2 Score:", r2_score(y_test, y_pred))
    print("RMSE:", mean_squared_error(y_test, y_pred, squared=False))

    return model

if __name__ == '__main__':
    df = load_data('../data/synthetic_housing.csv')
    eda(df)
    train_model(df)
