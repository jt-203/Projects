# Housing Price Regression

This project is a complete data science pipeline built in Python to predict housing prices using regression techniques. It demonstrates how a data analyst or data scientist can approach a structured problem, perform exploratory data analysis (EDA), apply machine learning, and generate insights that would be useful for business or policy decision-making.

---

## 📌 Project Motivation

Housing affordability is a critical concern in many regions. By analyzing historical housing data, we can better understand the factors influencing house prices. This helps local governments, investors, and buyers make informed decisions.

The key goals of this project are to:
- Analyze the relationships between economic and geographic features and housing prices
- Train and evaluate a regression model to predict house prices
- Identify which variables most influence price changes
- Provide clear, reproducible code for end-to-end analysis

---

## 📂 Folder Structure

```
housing_price_regression/
│
├── data/                  # Synthetic housing dataset
│   └── synthetic_housing.csv
│
├── notebooks/             # (Optional) Jupyter notebooks for interactive exploration
│
├── reports/               # Output plots and model evaluation
│   └── pairplot.png
│
├── src/                   # Main scripts for analysis and modeling
│   └── housing_model.py
│
├── requirements.txt       # Python dependencies
└── README.md              # Project overview and instructions
```

---

## 🧠 Features Used

| Feature           | Description                                  |
|------------------|----------------------------------------------|
| `median_income`  | Median income in the neighborhood             |
| `house_age`      | Age of the house                              |
| `avg_rooms`      | Average number of rooms per household         |
| `avg_bedrooms`   | Average number of bedrooms per household      |
| `population`     | Total population in the block                 |
| `latitude`       | Geographic latitude                           |
| `longitude`      | Geographic longitude                          |

---

## 🔬 Exploratory Data Analysis (EDA)

EDA includes:
- Descriptive statistics
- Pairwise relationships using Seaborn's pairplot
- Correlation matrix heatmap (optional)
- Visualizations to understand the distribution and outliers

---

## ⚙️ Model Pipeline

1. **Data Preprocessing**
   - Handling missing values (none in synthetic)
   - Feature selection and scaling (optional)
2. **Train/Test Split**
   - 80/20 split for model evaluation
3. **Model Training**
   - Linear regression using `scikit-learn`
   - Evaluate with R² and RMSE
4. **Model Interpretation**
   - Coefficients and feature importance

---

## 📈 Example Output

The model learns a linear relationship and produces:
- **R² score**: Accuracy metric that indicates how well predictions approximate the real data
- **RMSE**: Root Mean Square Error measures average prediction error

---

## 🚀 How to Run

1. Clone the repo or unzip the project
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Run the main script:
```bash
python src/housing_model.py
```

---

## 🧩 Future Enhancements

- Add a Jupyter notebook with interactive widgets
- Try advanced models (Random Forest, XGBoost)
- Build a Streamlit dashboard to explore data visually
- Perform feature engineering (e.g., rooms per household)

---

## 🧪 Dependencies

- Python 3.8+
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- jupyter (optional)

---

## 📬 Contact

Built by a data science enthusiast to demonstrate regression modeling skills.
