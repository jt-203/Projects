# Data Science Analysis Project

This project demonstrates a complete data analysis workflow using Python. It includes data cleaning, exploratory data analysis (EDA), and basic machine learning.
