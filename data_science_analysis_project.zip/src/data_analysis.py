import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression


def load_data(path):
    return pd.read_csv(path)


def clean_data(df):
    # Fill missing values with median
    df.fillna(df.median(), inplace=True)
    return df


def perform_eda(df):
    print('Data Info:', df.info())
    print('Statistical Summary:', df.describe())
    sns.pairplot(df)
    plt.savefig('data/eda_pairplot.png')
    plt.close()


def train_model(df, target):
    X = df.drop(columns=[target])
    y = df[target]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LinearRegression()
    model.fit(X_train, y_train)
    score = model.score(X_test, y_test)
    print(f'Model R2 Score: {score}')
    return model
